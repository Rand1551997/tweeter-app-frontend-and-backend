package edu.byu.cs.tweeter.server.dao.factories;

public class iImageDAO {
}
