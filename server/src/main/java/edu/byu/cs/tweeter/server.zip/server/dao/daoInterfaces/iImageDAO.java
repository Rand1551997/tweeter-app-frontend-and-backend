package edu.byu.cs.tweeter.server.dao.daoInterfaces;

public interface iImageDAO {
}
